package com.assignment.makersharks;

import com.assignment.makersharks.controller.SupplierController;
import com.assignment.makersharks.model.Supplier;
import com.assignment.makersharks.model.SupplierSearchRequest;
import com.assignment.makersharks.service.SupplierService;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Collections;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(SupplierController.class)
public class MakersharksApplicationTests {

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private SupplierService supplierService;

	@Autowired
	private ObjectMapper objectMapper;

	@Test
	public void testSearchSuppliers() throws Exception {
		SupplierSearchRequest request = new SupplierSearchRequest();
		request.setLocation("India");
		request.setNatureOfBusiness(Supplier.NatureOfBusiness.SMALL_SCALE);
		request.setManufacturingProcess(Supplier.ManufacturingProcess.D3_PRINTING);

		when(supplierService.searchSuppliers(any(SupplierSearchRequest.class)))
				.thenReturn(Collections.emptyList());

		mockMvc.perform(post("/api/supplier/query")
						.contentType(MediaType.APPLICATION_JSON)
						.content(objectMapper.writeValueAsString(request)))
				.andExpect(status().isOk());
	}
}
