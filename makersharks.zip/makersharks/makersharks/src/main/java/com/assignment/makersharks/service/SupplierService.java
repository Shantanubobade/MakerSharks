package com.assignment.makersharks.service;

import com.assignment.makersharks.model.Supplier;
import com.assignment.makersharks.model.SupplierSearchRequest;
import com.assignment.makersharks.repository.SupplierRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SupplierService {

    @Autowired
    private SupplierRepository supplierRepository;

    public List<Supplier> searchSuppliers(SupplierSearchRequest request) {
        PageRequest pageRequest = PageRequest.of(request.getOffset(), request.getLimit());
        return supplierRepository.findSuppliers(
                request.getLocation(),
                request.getNatureOfBusiness(),
                request.getManufacturingProcess(),
                pageRequest
        );
    }
}
