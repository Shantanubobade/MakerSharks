package com.assignment.makersharks.controller;

import com.assignment.makersharks.model.Supplier;
import com.assignment.makersharks.service.SupplierService;
import com.assignment.makersharks.model.SupplierSearchRequest;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/supplier")
@Tag(name = "Supplier", description = "Supplier search API")
public class SupplierController {

    @Autowired
    private SupplierService supplierService;

    @PostMapping("/query")
    @Operation(summary = "Search suppliers", description = "Search suppliers based on location, nature of business, and manufacturing process")
    public ResponseEntity<List<Supplier>> searchSuppliers(@Valid @RequestBody SupplierSearchRequest request) {
        List<Supplier> suppliers = supplierService.searchSuppliers(request);
        return ResponseEntity.ok(suppliers);
    }
}
