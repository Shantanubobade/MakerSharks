package com.assignment.makersharks;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MakersharksApplication {
	public static void main(String[] args) {
		SpringApplication.run(MakersharksApplication.class, args);
	}
}
