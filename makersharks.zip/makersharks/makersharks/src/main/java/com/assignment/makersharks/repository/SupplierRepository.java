package com.assignment.makersharks.repository;

import com.assignment.makersharks.model.Supplier;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface SupplierRepository extends MongoRepository<Supplier, String> {
    @Query("{'location': ?0, 'natureOfBusiness': ?1, 'manufacturingProcesses': ?2}")
    List<Supplier> findSuppliers(String location, Supplier.NatureOfBusiness natureOfBusiness, Supplier.ManufacturingProcess manufacturingProcess, Pageable pageable);
}
