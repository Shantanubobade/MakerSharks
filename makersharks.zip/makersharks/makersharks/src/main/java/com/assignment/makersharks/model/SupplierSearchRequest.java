package com.assignment.makersharks.model;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class SupplierSearchRequest {
    @NotBlank(message = "Location is required")
    private String location;

    @NotNull(message = "Nature of business is required")
    private Supplier.NatureOfBusiness natureOfBusiness;

    @NotNull(message = "Manufacturing process is required")
    private Supplier.ManufacturingProcess manufacturingProcess;

    @Min(1)
    private int limit = 10;

    @Min(0)
    private int offset = 0;
}
